controls:
WASD: 		move selector
arrow keys:	move blocks/navagate menus
z:		undo move
enter:		select in menus

-currently 30 levels
